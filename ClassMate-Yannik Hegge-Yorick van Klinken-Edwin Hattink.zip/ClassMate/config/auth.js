module.exports = {
	'googleAuth' : {
        'clientID'      : '132410763562-ittomvev77dqbi2a9p1kbe4jkahnikvb.apps.googleusercontent.com',
        'clientSecret'  : 'wt_T8e61-lC9_px35QIJo3Ek',
        //'callbackURL'   : 'http://localhost:3000/auth/google/callback'
        'callbackURL'   : '/auth/google/callback'
    }
};